cls

$ErrorActionPreference = "Stop"

$currentPath = (Split-Path $MyInvocation.MyCommand.Definition -Parent)

#Create Archive Folder 

new-item -Name "Archive" -Force -ItemType directory -Path "$currentPath"  | Out-Null

Import-Module "C:\Program Files\WindowsPowerShell\Modules\PowerBIPS" -Force

while($true)

{

	# Iterate each CSV file and send to PowerBI

	Get-ChildItem "$currentPath" -Filter "*.csv" |% { 

			 $file=$_             

			#Import csv and add column with filename

			$data = Import-Csv $_.FullName	

			# Send data to PowerBI

			$data |  Out-PowerBI -dataSetName "DeathsByYear" -tableName "DeathsByYear" -batchSize 300 -verbose
			
			
			# Archive the file

			Move-Item $file.FullName "$currentPath\Archive\" -Force

	}



	Write-Output "Sleeping..."

	Sleep -Seconds 5

}